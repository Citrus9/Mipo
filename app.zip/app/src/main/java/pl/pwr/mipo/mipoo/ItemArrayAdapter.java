package pl.pwr.mipo.mipoo;

import java.util.List;

import android.content.Context;
import android.graphics.Paint;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.TextView;

public class ItemArrayAdapter 
		extends BaseItemArrayAdapter {
	
	public ItemArrayAdapter(Context context, ListViewStatusChangeListener listenerCb, int textViewResourceId, List<Product> results) {
		super(context, listenerCb, textViewResourceId, results);
		
	}
	
	@Override
	protected void populateRow(View v, Product item, int position) {
		
		if (item != null) {
//			TextView itemQuantity = (TextView) v.findViewById(R.id.item_row_item_quantity);
			TextView itemName = (TextView) v.findViewById(R.id.item_name);
			CheckBox itemComplete = (CheckBox) v.findViewById(R.id.completeBox);

//			if (itemQuantity != null) {
//
//				if (item.getQuantity()!=0){
//					String displayName = item.getQuantityType().getDisplayName();
//
//					StringBuilder displayQty = new StringBuilder(item.getQuantity().toString());
//					if (displayQty.substring(displayQty.length() - 2).equals(".0")) {
//						displayQty = displayQty.delete(displayQty.length() - 2, displayQty.length());
//					}
//					if (displayName.length() > 0) {
//						displayQty = displayQty.append(" ").append(displayName);
//					}
//					itemQuantity.setVisibility(View.VISIBLE);
//					itemQuantity.setText(displayQty.toString());
//				}
//
//				else{
//
//				    itemQuantity.setVisibility(View.GONE);
//				}
//			}
			
			if (itemName != null){
				if(item.getComplete()==0){
					if ((itemName.getPaintFlags() & Paint.STRIKE_THRU_TEXT_FLAG) > 0){
						itemName.setText(item.getName());
						itemName.setPaintFlags( itemName.getPaintFlags() & (~ Paint.STRIKE_THRU_TEXT_FLAG));
					}
					else{
						itemName.setText(item.getName());
					}
				}
				else{
					itemName.setText(item.getName());
					itemName.setPaintFlags(itemName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
				}
			}
			
			if (itemComplete != null) {
                if(item.getComplete()==1){
                    itemComplete.setChecked(true);
                }
                else{
                    itemComplete.setChecked(true);
                }
		
				final int thisPosition = position;
				itemComplete.setOnClickListener(new OnClickListener() {
					
					public void onClick(View v) {
						CheckBox box = (CheckBox)v.findViewById(R.id.completeBox);
						listenerCb.statusChanged(thisPosition, v, box.isChecked()); 
					}
				});
			}
			
		}
	}

}
