package pl.pwr.mipo.mipoo;

/**
 * Created by CitrusPanc on 4/10/2015.
 */
import java.util.List;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

public abstract class BaseItemArrayAdapter
        extends ArrayAdapter<Product> {
    private List<Product> shoppingListItems;
    private int textViewResourceId;

    protected ListViewStatusChangeListener listenerCb;

    public BaseItemArrayAdapter(Context context, ListViewStatusChangeListener listenerCb, int textViewResourceId, List<Product> results) {
        super(context, textViewResourceId, results);
        this.textViewResourceId = textViewResourceId;

        this.shoppingListItems = results;
        this.listenerCb = listenerCb;
    }

    protected abstract void populateRow(View v, Product item, int position);

    public View getView(int position, View convertView, ViewGroup parent){

        // assign the view we are converting to a local variable
        View v = convertView;

        // first check to see if the view is null. if so, we have to inflate it.
        // to inflate it basically means to render, or show, the view.
        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(textViewResourceId, null);
        }

		/*
		 * Recall that the variable position is sent in as an argument to this method.
		 * The variable simply refers to the position of the current object in the list. (The ArrayAdapter
		 * iterates through the list we sent it)
		 *
		 * Therefore, i refers to the current Item object.
		 */
        Product i = shoppingListItems.get(position);
        if (i != null) {
            populateRow(v, i, position);
        }

        // the view must be returned to our activity
        return v;
    }

}