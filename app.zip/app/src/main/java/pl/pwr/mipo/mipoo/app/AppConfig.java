package pl.pwr.mipo.mipoo.app;

/**
 * Created by CitrusPanc on 4/18/2015.
 */
public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http://156.17.130.213/android_login_api/";

    // Server user register url
    public static String URL_REGISTER = "http://156.17.130.213/android_login_api/";
}